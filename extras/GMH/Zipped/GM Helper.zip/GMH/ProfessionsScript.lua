﻿function LearnJewel()
result=".character advancesk 755 "..SkillLevel:GetText();    
outSAY(result);
end

function LearnBlackSmithing()
result=".character advancesk 164 "..SkillLevel:GetText();    
outSAY(result);
end

function LearnTailoring()
result=".character advancesk 197 "..SkillLevel:GetText();    
outSAY(result);
end

function LearnLeatherworking()
result=".character advancesk 165 "..SkillLevel:GetText();    
outSAY(result);
end

function LearnEngineering()
result=".character advancesk 202 "..SkillLevel:GetText();    
outSAY(result);
end

function LearnPoisons()
result=".character advancesk 40 "..SkillLevel:GetText();    
outSAY(result);
end

function LearnEnchanting()
result=".character advancesk 333 "..SkillLevel:GetText();    
outSAY(result);
end

function LearnFishing()
result=".character advancesk 356 "..SkillLevel:GetText();    
outSAY(result);
end

function LearnMining()
result=".character advancesk 186 "..SkillLevel:GetText();    
outSAY(result);
end

function LearnSkinning()
result=".character advancesk 393 "..SkillLevel:GetText();    
outSAY(result);
end

function LearnAlchemy()
result=".character advancesk 171 "..SkillLevel:GetText();    
outSAY(result);
end

function LearnHerbalism()
result=".character advancesk 182 "..SkillLevel:GetText();    
outSAY(result);
end

function LearnFirstAid()
result=".character advancesk 129 "..SkillLevel:GetText();    
outSAY(result);
end

function LearnCooking()
result=".character advancesk 185 "..SkillLevel:GetText();    
outSAY(result);
end
