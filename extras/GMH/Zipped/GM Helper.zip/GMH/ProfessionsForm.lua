﻿function LearnBlackSmithing()
result=".character advancesk 164 "..SkillLvl:GetText();    
outSAY(result);
end

function LearnTailoring()
result=".character advancesk 197 "..SkillLvl:GetText();    
outSAY(result);
end

function LearnLeatherworking()
result=".character advancesk 165 "..SkillLvl:GetText();    
outSAY(result);
end

function LearnEngineering()
result=".character advancesk 202 "..SkillLvl:GetText();    
outSAY(result);
end

function LearnPoisons()
result=".character advancesk 40 "..SkillLvl:GetText();    
outSAY(result);
end

function LearnEnchanting()
result=".character advancesk 333 "..SkillLvl:GetText();    
outSAY(result);
end

function LearnFishing()
result=".character advancesk 356 "..SkillLvl:GetText();    
outSAY(result);
end

function LearnMining()
result=".character advancesk 186 "..SkillLvl:GetText();    
outSAY(result);
end

function LearnSkinning()
result=".character advancesk 393 "..SkillLvl:GetText();    
outSAY(result);
end

function LearnAlchemy()
result=".character advancesk 171 "..SkillLvl:GetText();    
outSAY(result);
end

function LearnHerbalism()
result=".character advancesk 182 "..SkillLvl:GetText();    
outSAY(result);
end

function LearnFirstAid()
result=".character advancesk 129 "..SkillLvl:GetText();    
outSAY(result);
end

function LearnCooking()
result=".character advancesk 185 "..SkillLvl:GetText();    
outSAY(result);
end

function LearnRiding()
result=".character advancesk 762 "..RidingLevel:GetText();    
outSAY(result);
end
