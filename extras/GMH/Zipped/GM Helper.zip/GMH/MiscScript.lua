﻿function SInfo()
    result=".server info";
    outSAY(result);
end

function Invis()
    result=".invisible";
    outSAY(result);
end

function Invince()
    result=".invincible";
    outSAY(result);
end
