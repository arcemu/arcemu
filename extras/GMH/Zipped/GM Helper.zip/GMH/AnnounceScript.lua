﻿function FirstAnnounce()
firstannounce=".announce "..SetAnnounceText:GetText();    
end

function SecondAnnounce()
secondannounce=".announce "..SetAnnounceText:GetText();    
end

function ThirdAnnounce()
thirdannounce=".announce "..SetAnnounceText:GetText();    
end

function ForthAnnounce()
forthannounce=".announce "..SetAnnounceText:GetText();    
end

function FifthAnnounce()
fifthannounce=".announce "..SetAnnounceText:GetText();    
end
