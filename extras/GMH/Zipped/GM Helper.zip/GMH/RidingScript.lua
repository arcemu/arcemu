﻿function LearnRiding()
result=".character learnsk 762 "..RidingLevel:GetText();    
outSAY(result);
end