﻿function LearnDualWield()
result=".character advancesk 118 "..WeaponSkillLvl:GetText();    
outSAY(result);
end

function LearnStaves()
result=".character advancesk 136 "..WeaponSkillLvl:GetText();    
outSAY(result);
end

function LearnUnarmed()
result=".character advancesk 136 "..WeaponSkillLvl:GetText();    
outSAY(result);
end

function LearnTwoHandedAxes()
result=".character advancesk 172 "..WeaponSkillLvl:GetText();    
outSAY(result);
end

function LearnDaggers()
result=".character advancesk 173 "..WeaponSkillLvl:GetText();    
outSAY(result);
end


function LearnCrossbows()
result=".character advancesk 226 "..WeaponSkillLvl:GetText();    
outSAY(result);
end


function LearnWands()
result=".character advancesk 228 "..WeaponSkillLvl:GetText();    
outSAY(result);
end


function LearnPolearms()
result=".character advancesk 229 "..WeaponSkillLvl:GetText();    
outSAY(result);
end


function LearnGuns()
result=".character advancesk 46 "..WeaponSkillLvl:GetText();    
outSAY(result);
end

function LearnSwords()
result=".character advancesk 43 "..WeaponSkillLvl:GetText();    
outSAY(result);
end

function LearnTwoHandedSwords()
result=".character advancesk 55 "..WeaponSkillLvl:GetText();    
outSAY(result);
end

function LearnFistWeapons()
result=".character advancesk 473 "..WeaponSkillLvl:GetText();    
outSAY(result);
end

function LearnTwoHandedMaces()
result=".character advancesk 160 "..WeaponSkillLvl:GetText();    
outSAY(result);
end

function LearnBows()
result=".character advancesk 45 "..WeaponSkillLvl:GetText();    
outSAY(result);
end

function LearnThrown()
result=".character advancesk 176 "..WeaponSkillLvl:GetText();    
outSAY(result);
end

function LearnAxes()
result=".character advancesk 44 "..WeaponSkillLvl:GetText();    
outSAY(result);
end

function LearnMaces()
result=".character advancesk 54 "..WeaponSkillLvl:GetText();    
outSAY(result);
end
